import test from 'node:test';
import assert from 'node:assert/strict';
import { allowedChoices, isSafeImageUrl, validateQuizPayload, validateSubmission } from '../lib/validation.js';
const choices = ['R','C','F','Z','K','A','V','B','S'];
test('accepts the seeded letter quiz', () => {
  assert.equal(validateQuizPayload({slug:'letter-odd-one-out-001',title:'Odd letter',question_text:'Choose the odd letter',answer_key:'A',coin_reward:1,choices,image_url:'/uploads/quiz-001.jpg'}), null);
});
test('rejects answer not in choices', () => {
  assert.match(validateQuizPayload({slug:'quiz-001',title:'Odd letter',question_text:'Choose',answer_key:'Q',coin_reward:1,choices,image_url:null}), /match one of the choices/);
});
test('rejects duplicate or oversized choice sets', () => {
  assert.equal(allowedChoices(['A','a']), false);
  assert.equal(allowedChoices(['A']), false);
  assert.equal(allowedChoices(Array(13).fill().map((_,i)=>String(i))), false);
});
test('rejects unsafe image schemes', () => {
  assert.equal(isSafeImageUrl('javascript:alert(1)'), false);
  assert.equal(isSafeImageUrl('http://example.com/image.png'), false);
  assert.equal(isSafeImageUrl('https://example.com/image.png'), true);
});
test('requires consent acknowledgement and valid nickname', () => {
  const payload={displayName:'MathStar',participantKey:'0123456789abcdef',quizSlug:'quiz-001',answer:'A',consentAck:true};
  assert.equal(validateSubmission(payload),null);
  assert.match(validateSubmission({...payload,consentAck:false}),/acknowledgement/);
});
