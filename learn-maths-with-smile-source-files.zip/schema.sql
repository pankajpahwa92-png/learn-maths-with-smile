-- Run this on a PostgreSQL database. Safe to run again for this starter's schema changes.
CREATE TABLE IF NOT EXISTS students (
  id BIGSERIAL PRIMARY KEY,
  display_name TEXT NOT NULL,
  contact_phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE students ADD COLUMN IF NOT EXISTS participant_key TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS leaderboard_opt_in BOOLEAN NOT NULL DEFAULT false;
UPDATE students SET participant_key='legacy_'||id::text WHERE participant_key IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS students_participant_key_unique ON students(participant_key);
ALTER TABLE students ALTER COLUMN participant_key SET NOT NULL;
CREATE TABLE IF NOT EXISTS quizzes (
  id BIGSERIAL PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  question_text TEXT NOT NULL,
  answer_key TEXT NOT NULL,
  coin_reward INTEGER NOT NULL DEFAULT 1 CHECK (coin_reward >= 0),
  active BOOLEAN NOT NULL DEFAULT true,
  image_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE quizzes ADD COLUMN IF NOT EXISTS image_url TEXT;
ALTER TABLE quizzes ADD COLUMN IF NOT EXISTS choices JSONB NOT NULL DEFAULT '[]'::jsonb;
CREATE TABLE IF NOT EXISTS submissions (
  id BIGSERIAL PRIMARY KEY,
  student_id BIGINT NOT NULL REFERENCES students(id),
  quiz_id BIGINT NOT NULL REFERENCES quizzes(id),
  answer TEXT NOT NULL,
  is_correct BOOLEAN NOT NULL,
  consent_ack BOOLEAN NOT NULL DEFAULT false,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE submissions ADD COLUMN IF NOT EXISTS consent_ack BOOLEAN NOT NULL DEFAULT false;
CREATE UNIQUE INDEX IF NOT EXISTS submissions_one_attempt_per_student_quiz ON submissions(student_id,quiz_id);
CREATE TABLE IF NOT EXISTS coin_ledger (
  id BIGSERIAL PRIMARY KEY,
  student_id BIGINT NOT NULL REFERENCES students(id),
  submission_id BIGINT REFERENCES submissions(id),
  amount INTEGER NOT NULL CHECK (amount >= 0),
  reason TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO quizzes (slug,title,question_text,answer_key,coin_reward,image_url,choices)
VALUES ('letter-odd-one-out-001','Quiz #001 — Find the odd one out','Put a cross (X) on the odd one out letter: R C F Z K A V B S','A',1,'/uploads/quiz-001.jpg','["R","C","F","Z","K","A","V","B","S"]'::jsonb)
ON CONFLICT (slug) DO NOTHING;
UPDATE quizzes SET choices=CASE WHEN choices IS NULL OR choices='[]'::jsonb THEN '[\"R\",\"C\",\"F\",\"Z\",\"K\",\"A\",\"V\",\"B\",\"S\"]'::jsonb ELSE choices END, image_url=COALESCE(image_url,'/uploads/quiz-001.jpg') WHERE slug='letter-odd-one-out-001';
