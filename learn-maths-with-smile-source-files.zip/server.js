import 'dotenv/config';
import express from 'express';
import pg from 'pg';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import { fileTypeFromBuffer } from 'file-type';
import { randomUUID, timingSafeEqual } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { validateQuizPayload, validateSubmission } from './lib/validation.js';
const { Pool } = pg;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadDir = path.join(__dirname, 'public', 'uploads');
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY === '1');
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'"],styleSrc:["'self'","'unsafe-inline'"],imgSrc:["'self'","https:"],connectSrc:["'self'"],objectSrc:["'none'"],baseUri:["'self'"],frameAncestors:["'none'"]}}}));
app.use(express.json({ limit: '256kb' }));
app.use('/uploads', express.static(uploadDir, { dotfiles:'deny', index:false, maxAge:'7d' }));
app.use(express.static(path.join(__dirname,'public')));
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10, idleTimeoutMillis: 30000, connectionTimeoutMillis: 5000 });
const adminToken = process.env.ADMIN_TOKEN || '';
function adminOnly(req,res,next){
  const supplied=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
  const a=Buffer.from(supplied),b=Buffer.from(adminToken);
  if(!adminToken || a.length!==b.length || !timingSafeEqual(a,b)) return res.status(401).json({error:'Unauthorized'});
  next();
}
const submitLimiter=rateLimit({windowMs:15*60*1000,max:30,standardHeaders:'draft-7',legacyHeaders:false,message:{error:'Too many attempts. Please try again later.'}});
const adminLimiter=rateLimit({windowMs:15*60*1000,max:100,standardHeaders:'draft-7',legacyHeaders:false});
const uploadLimiter=rateLimit({windowMs:60*60*1000,max:10,standardHeaders:'draft-7',legacyHeaders:false});
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024,files:1},fileFilter:(req,file,cb)=>cb(null,['image/jpeg','image/png','image/webp'].includes(file.mimetype))});
app.get('/api/quiz/:slug', async (req,res)=>{
  try { const q=await pool.query('SELECT id,slug,title,question_text,coin_reward,image_url,choices FROM quizzes WHERE slug=$1 AND active=true',[req.params.slug]); if(!q.rowCount)return res.status(404).json({error:'Quiz not found'});res.json(q.rows[0]); }
  catch { res.status(500).json({error:'Server error'}); }
});
app.get('/api/leaderboard',async (_req,res)=>{
  try { const q=await pool.query(`SELECT st.display_name AS nickname, COALESCE(SUM(cl.amount),0)::int AS coins FROM students st JOIN coin_ledger cl ON cl.student_id=st.id WHERE st.leaderboard_opt_in=true GROUP BY st.id,st.display_name ORDER BY coins DESC,st.display_name ASC LIMIT 10`);res.json(q.rows); }
  catch {res.status(500).json({error:'Server error'});}
});
app.post('/api/submit',submitLimiter,async(req,res)=>{
  const payload=req.body??{}; const error=validateSubmission(payload);if(error)return res.status(400).json({error});
  const {displayName,participantKey,quizSlug,answer,leaderboardOptIn}=payload;
  if(typeof leaderboardOptIn!=='boolean')return res.status(400).json({error:'Invalid leaderboard setting'});
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const quiz=await client.query('SELECT id,answer_key,coin_reward FROM quizzes WHERE slug=$1 AND active=true',[quizSlug]);
    if(!quiz.rowCount){await client.query('ROLLBACK');return res.status(404).json({error:'Quiz not found'});}
    const student=await client.query(`INSERT INTO students(display_name,participant_key,leaderboard_opt_in) VALUES($1,$2,$3) ON CONFLICT(participant_key) DO UPDATE SET display_name=EXCLUDED.display_name,leaderboard_opt_in=EXCLUDED.leaderboard_opt_in RETURNING id`,[displayName.trim(),participantKey,leaderboardOptIn]);
    const existing=await client.query('SELECT id FROM submissions WHERE student_id=$1 AND quiz_id=$2',[student.rows[0].id,quiz.rows[0].id]);
    if(existing.rowCount){await client.query('ROLLBACK');return res.status(409).json({error:'This browser has already attempted this quiz. Try a new quiz next time.'});}
    const isCorrect=answer.trim().toUpperCase()===quiz.rows[0].answer_key.trim().toUpperCase();
    const sub=await client.query('INSERT INTO submissions(student_id,quiz_id,answer,is_correct,consent_ack) VALUES($1,$2,$3,$4,$5) RETURNING id',[student.rows[0].id,quiz.rows[0].id,answer.trim(),isCorrect,true]);
    const coins=isCorrect?quiz.rows[0].coin_reward:0;
    if(coins>0)await client.query('INSERT INTO coin_ledger(student_id,submission_id,amount,reason) VALUES($1,$2,$3,$4)',[student.rows[0].id,sub.rows[0].id,coins,'Correct quiz answer']);
    await client.query('COMMIT');res.json({correct:isCorrect,coinsAwarded:coins,message:isCorrect?'Correct! You earned Smiley Coins.':'Nice try! Keep practicing.'});
  }catch(e){await client.query('ROLLBACK');if(e?.code==='23505')return res.status(409).json({error:'This quiz attempt was already recorded.'});res.status(500).json({error:'Server error'});}
  finally{client.release();}
});
app.post('/api/admin/upload',adminOnly,adminLimiter,uploadLimiter,(req,res,next)=>upload.single('image')(req,res,e=>{if(e)return res.status(400).json({error:'Upload failed. Use JPG, PNG or WebP up to 5 MB.'});next();}),async(req,res)=>{
  if(!req.file)return res.status(400).json({error:'Choose an image file'});
  const type=await fileTypeFromBuffer(req.file.buffer);
  const extByMime={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'};
  if(!type||!extByMime[type.mime]||type.mime!==req.file.mimetype)return res.status(400).json({error:'The image file could not be verified'});
  try{await mkdir(uploadDir,{recursive:true});const filename=`${randomUUID()}.${extByMime[type.mime]}`;await writeFile(path.join(uploadDir,filename),req.file.buffer,{flag:'wx'});res.status(201).json({image_url:`/uploads/${filename}`});}
  catch{res.status(500).json({error:'Image storage failed'});}
});
app.post('/api/admin/quizzes',adminOnly,adminLimiter,async(req,res)=>{
  const error=validateQuizPayload(req.body);if(error)return res.status(400).json({error});
  const {slug,title,question_text,answer_key,coin_reward,image_url,choices}=req.body;
  try{const q=await pool.query('INSERT INTO quizzes(slug,title,question_text,answer_key,coin_reward,image_url,choices) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,slug,title,coin_reward,active',[slug,title.trim(),question_text.trim(),answer_key.trim(),coin_reward,image_url||null,JSON.stringify(choices.map(c=>c.trim()))]);res.status(201).json(q.rows[0]);}
  catch{res.status(409).json({error:'Quiz slug may already exist or database error'});}
});
app.get('/api/admin/quizzes',adminOnly,adminLimiter,async(_req,res)=>{
  try{const q=await pool.query('SELECT id,slug,title,active,coin_reward,created_at FROM quizzes ORDER BY created_at DESC');res.json(q.rows);}
  catch{res.status(500).json({error:'Server error'});}
});
app.patch('/api/admin/quizzes/:id/active',adminOnly,adminLimiter,async(req,res)=>{
  if(typeof req.body?.active!=='boolean')return res.status(400).json({error:'active must be boolean'});
  try{const q=await pool.query('UPDATE quizzes SET active=$1 WHERE id=$2 RETURNING id,slug,active',[req.body.active,req.params.id]);if(!q.rowCount)return res.status(404).json({error:'Quiz not found'});res.json(q.rows[0]);}
  catch{res.status(500).json({error:'Server error'});}
});
app.get('/api/admin/submissions',adminOnly,adminLimiter,async(req,res)=>{
  try{const q=await pool.query(`SELECT s.submitted_at,st.display_name,q.slug AS quiz,s.answer,s.is_correct,s.consent_ack,st.leaderboard_opt_in,COALESCE((SELECT SUM(amount) FROM coin_ledger cl WHERE cl.submission_id=s.id),0)::int AS coins FROM submissions s JOIN students st ON st.id=s.student_id JOIN quizzes q ON q.id=s.quiz_id ORDER BY s.submitted_at DESC LIMIT 1000`);res.json(q.rows);}
  catch{res.status(500).json({error:'Server error'});}
});
app.get('/api/admin/summary',adminOnly,adminLimiter,async(_req,res)=>{
  try{const q=await pool.query(`SELECT count(*)::int AS submissions,count(*) FILTER(WHERE is_correct)::int AS correct FROM submissions`);const coins=await pool.query('SELECT COALESCE(sum(amount),0)::int AS coins FROM coin_ledger');const students=await pool.query('SELECT count(*)::int AS students FROM students');res.json({...q.rows[0],coins:coins.rows[0].coins,students:students.rows[0].students});}
  catch{res.status(500).json({error:'Server error'});}
});
app.get('/health',(_req,res)=>res.json({ok:true}));
app.use((err,_req,res,_next)=>{if(err?.code==='LIMIT_FILE_SIZE')return res.status(413).json({error:'Image too large (5 MB limit)'});res.status(500).json({error:'Server error'});});
const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`LMWS API listening on port ${port}`));
