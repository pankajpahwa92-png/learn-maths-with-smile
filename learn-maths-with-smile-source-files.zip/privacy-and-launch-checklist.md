# Privacy & launch checklist — V5

- [ ] Review the applicable Indian DPDP Act/rules and requirements for any other countries served.
- [ ] Provide and implement a meaningful parent/guardian consent process before collecting children's data. The current acknowledgement checkbox is not verified consent.
- [ ] Privacy notice: collection, purposes, public leaderboard, retention, deletion, contact and consent/revocation.
- [ ] Use nicknames; discourage identifiable names. V5 does not collect student phone numbers.
- [ ] Limit leaderboard exposure; ensure opt-in and allow opt-out/deletion.
- [ ] Provide a deletion workflow for participant data, submissions and ledger records as appropriate.
- [ ] Replace shared admin token with a secure admin account system and MFA; add audit logging.
- [ ] HTTPS, correct reverse-proxy configuration, secure secret storage and rate-limit tuning.
- [ ] Persistent uploads, DB backup and restore tests; monitor file/disk usage.
- [ ] Review hosting disk persistence, migrations, unique-index compatibility, and one-attempt semantics.
- [ ] Test deployment, student flow, upload flow, quiz creation, leaderboard and export with dummy data.
- [ ] Define Smiley Coin terms; avoid cash-equivalent/prize claims without legal review.
