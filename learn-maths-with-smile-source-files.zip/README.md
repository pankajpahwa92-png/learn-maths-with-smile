# Learn Maths with Smile — V5

V5 is an incremental self-hostable starter: image uploads, quiz choices authored by the admin, a student nickname flow, one attempt per participant/browser per quiz, server-calculated Smiley Coins, an opt-in nickname leaderboard, a private token-based admin dashboard and CSV export.

## V5 changes
- Fixes the malformed V4 schema text and makes `schema.sql` include idempotent additions for existing V4 tables.
- Adds the supplied first puzzle image as `public/uploads/quiz-001.jpg` and seeds its 3×3 choices: R, C, F / Z, K, A / V, B, S; correct answer A; one coin.
- Admin uploads JPG, PNG or WebP (verified file signature, max 5 MB), then the server stores it with a generated filename. Admin can author 2–12 choices, one per line, and create quizzes.
- Server-side answer validation and ledger entry; a unique index limits one submission per participant-key/quiz pair.
- Uses a browser-generated participant key in localStorage. Students use nicknames, no phone number is collected by the V5 student form. Leaderboard is opt-in and public nicknames only.
- Helmet security headers, request rate limits, server-side input validation, parameterized SQL, timing-safe token comparison.
- Dashboard summary, response list and CSV export (no phone numbers in response data).
- Built-in tests for validation and image URL rules.

## Run locally
1. Install Node.js 20+ and PostgreSQL (or use your own hosted PostgreSQL).
2. `npm install`
3. Create a database and run `psql "$DATABASE_URL" -f schema.sql` (set `DATABASE_URL` first, or run the file against your chosen DB).
4. Copy `.env.example` to `.env`, configure `DATABASE_URL` and a long random `ADMIN_TOKEN`.
5. `npm run check` (does not require the database).
6. `npm start`, then open `http://localhost:3000/student.html` or `/` for admin.

## Database migration note
The script adds columns/indexes to the V4 scaffold. Back up the database before running migrations. The unique attempt index can fail if an existing database has duplicate submissions for the same student/quiz pair; inspect and resolve those rows before applying it.

## Persistent uploads
Uploads are written to `public/uploads/`. On some hosting services, local disk is ephemeral and/or shared across instances. Use persistent volume storage or object storage before production; this starter does not configure a storage service or backups.

## Admin
Enter the value of `ADMIN_TOKEN` into the admin dashboard. It is not stored by the page. The bearer token is still a shared-token prototype, not full login/MFA/role-based authentication. Do not deploy publicly without stronger authentication, HTTPS, backup/restore, privacy and consent process, security review and testing.

## Child safety & privacy
- V5 intentionally removes mobile-number collection from the student form and asks for a nickname, not a full name.
- The guardian acknowledgement is only a UI acknowledgement, not verified consent or a legal compliance solution. It is not enough for a public launch.
- The opt-in leaderboard exposes nicknames and coin totals. Nicknames should not identify students.
- Browser participant keys can be reset, devices can be shared, and are not account identity or anti-cheat credentials.
- Review applicable Indian DPDP law/rules and any laws for children in other countries. Publish an age-appropriate privacy notice, implement an appropriate guardian-consent process, retention/deletion controls, abuse controls and contact channels before real use.
- Do not make Smiley Coins cash-equivalent or introduce prizes/contest mechanics without legal review.

## What remains
Production admin authentication, verified guardian consent, real account recovery, persistent/managed upload storage, database backups, deployment, HTTPS/domain configuration, monitoring, security/privacy/legal review and live end-to-end tests remain unconfigured.

## V6 milestone additions
- Admin quiz list and activate/deactivate controls (soft-disable; preserve historic responses).
- New protected API: `GET /api/admin/quizzes` and `PATCH /api/admin/quizzes/:id/active`.
- Admin dashboard displays quiz status and toggle controls.

## Deployment preparation (not deployed)
1. Use a host with Node.js 20+, HTTPS, and a managed PostgreSQL instance. Keep the database private to the application.
2. Copy `.env.example` to `.env`; set a strong random `ADMIN_TOKEN` (at least 32 random bytes), `DATABASE_URL`, and production port/proxy settings. Do not commit `.env`.
3. Provision PostgreSQL and apply `schema.sql` with a database role restricted to this database. Back up the database regularly and test restore.
4. Run `npm install`, `npm test`, then `npm start`. Configure HTTPS reverse proxy, persistent upload storage, backups, and monitoring.
5. Before accepting real children: replace token-based admin access with proper authentication (password hashing, secure sessions, MFA where possible), implement verified guardian consent and privacy/retention/deletion policy, review applicable Indian child-data laws and any laws in other target countries, and conduct a security review.
6. Avoid collecting child full names, phone numbers, email, school, location or birth dates. Nicknames are not guaranteed anonymous; treat them and responses as personal data. Do not publish the leaderboard by default without appropriate guardian/child choice and legal review.

V6 quiz toggles are not an authentication upgrade: admin access still uses the bearer token in the V5 design. Treat the token as a temporary private deployment credential, rotate it if exposed, and never run this on an untrusted public network before the launch checklist is completed.
